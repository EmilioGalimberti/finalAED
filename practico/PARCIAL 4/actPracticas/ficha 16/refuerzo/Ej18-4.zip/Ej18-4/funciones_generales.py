
def cargar_mayor_a(valor, mensaje):
    n = int(input(mensaje))
    while n <= valor:
        print("Error el número ingresado debe ser mayor a", valor)
        n = int(input(mensaje))

    return n
