class Deuda:
    def __init__(self, cliente, monto):
        self.cliente = cliente
        self.monto = monto


def mostrar(d):
    return "{:<20} ${:>6.2}".format(d.cliente, d.monto)

