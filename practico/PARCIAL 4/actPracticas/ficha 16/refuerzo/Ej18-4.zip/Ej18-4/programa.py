from deuda import *
from funciones_generales import *


# Recibe el vector y el monto maximo
# Calcula y retorna el porcentaje
def porcentaje_deudas_menor(v, tope):
    n = len(v)
    c = 0

    for deuda in v:
        if deuda.monto < tope:
            c += 1

    porcentaje = (c / n) * 100
    return porcentaje


# Recibe el vector
# (no muestra nada)
# Retorna un registro Deuda
def menor_deuda(v):

    menor = v[0]

    for deuda in v:
        if deuda.monto < menor.monto:
            menor = deuda

    return menor


# Recibe el vector
# Retorna el promedio
def calcular_promedio(v):
    suma_montos = 0
    n = len(v)

    # Alternativa 1
    #for i in range(n): # i es un entero para usar de índice del vector
    #     suma_montos += v[i].monto

    # Alternativa 2
    for cada_deuda in v: # cada_deuda es un registro del vector
        suma_montos += cada_deuda.monto

    promedio = suma_montos / n
    return promedio


# Recibe el tamaño del arreglo
# Lo crea y lo retorna
def cargar_arreglo(n):
    v = [None] * n
    for i in range(n):
        nombre = input("Ingrese el nombre de la persona deudora:")
        monto = int(input("Ingrese el monto adeudado:"))
        v[i] = Deuda(nombre, monto)

    return v




def principal():
    n = cargar_mayor_a(0, "Ingrese la cantidad de deudas: ")
    deudas = cargar_arreglo(n)

    promedio = calcular_promedio(deudas)
    print("Promedio de deudas:", promedio)
    menor = menor_deuda(deudas)
    print("Menor deuda:", mostrar(menor))

    maximo = cargar_mayor_a(0, "Ingrese la deuda máxima para el calculo del porcentaje")
    porcentaje = porcentaje_deudas_menor(deudas, maximo)

    print(round(porcentaje,2), "% de deudas son menores a ", maximo)


if __name__ == "__main__":
    principal()
